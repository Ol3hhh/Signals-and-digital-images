import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import cv2
# Funkcje pomocnicze
def dct2(a):
    return cv2.dct(a.astype(np.float32))

def idct2(a):
    return cv2.idct(a)

def apply_threshold(dct_coeffs, T):
    dct_coeffs[np.abs(dct_coeffs) <= T] = 0
    return dct_coeffs


image = Image.open('../Source/Fella.jpg').convert('RGB')
img = np.array(image)


dct_coeffs = dct2(img)


plt.figure(figsize=(10, 10))
plt.imshow(np.log(np.abs(dct_coeffs)))
plt.title('Współczynniki DCT')
plt.axis('off')
plt.show()


T = 10
dct_coeffs = apply_threshold(dct_coeffs, T)


processed_img = idct2(dct_coeffs)


processed_image = Image.fromarray(processed_img)


plt.figure(figsize=(10, 10))
plt.imshow(processed_img)
plt.title('Przetworzony obraz')
plt.axis('off')
plt.show()
