import numpy as np
import cupy as cp
from PIL import Image
import matplotlib.pyplot as plt

from dct_image import dct_matrix as dct, idct_matrix as idct
from threshold import threshold
from quantization import quantization
import plots
# Завантаження зображення
image = Image.open('../Source/Fella.jpg')
pixels = cp.array(image)


def generate_poisson_image(lm, image):
    return cp.random.poisson(lam=lm * image).astype(cp.float32)


poissoned_pixels = generate_poisson_image(1, pixels)
poissoned_image = Image.fromarray(cp.asnumpy(poissoned_pixels).astype(np.uint8))
poissoned_image.show()
plots.before(poissoned_pixels)

# Застосування DCT до зображення
dct_pixels = dct(poissoned_pixels)
dct_image = Image.fromarray(cp.asnumpy(dct_pixels).astype(np.uint8))
# dct_image.show()


#--------------------------------------------------------------------------------
T = 25
Q = 25
for i in range(5):
    for j in range(5):
        quantized_pixels = quantization(threshold(dct_pixels, T), Q)
        # thresholded_image = Image.fromarray(cp.asnumpy(quantized_pixels).astype(np.uint8))
        # thresholded_image.show()
        # plots.threshold(dct_pixels, quantized_pixels)
        idct_image = Image.fromarray(cp.asnumpy(idct(quantized_pixels)).astype(np.uint8))
        idct_image.save(f"../Preprocessed/T{T}____Q{Q}.png")
        print(str(i) + "      " +  str(j))
        T += 25
    T = 25
    Q += 25