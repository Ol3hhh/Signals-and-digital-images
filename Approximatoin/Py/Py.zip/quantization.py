import cupy as cp
import numpy as np


def quantization(pixels, Q):
    return cp.floor(Q*pixels + 0.5) / Q
