import cupy as cp
import numpy as np
from scipy.fftpack import dct, idct
from PIL import Image

def dct_matrix(pixels):
    # Функція для застосування DCT до кожного каналу
    def apply_dct(image_channel):
        dct_channel = dct(dct(cp.asnumpy(image_channel).T, norm='ortho').T, norm='ortho')
        return cp.array(dct_channel)  # Повернення до cupy

    # Застосування DCT до кожного каналу
    dct_pixels = cp.zeros_like(pixels, dtype=cp.float32)
    for i in range(3):
        dct_pixels[:, :, i] = apply_dct(pixels[:, :, i])

    return dct_pixels


def idct_matrix(pixels):
    # Застосування IDCT до зображення
    def apply_idct(image_channel):
        idct_channel = idct(idct(cp.asnumpy(image_channel).T, norm='ortho').T, norm='ortho')
        return cp.array(idct_channel)  # Повернення до cupy

    # Застосування IDCT до кожного каналу
    idct_pixels = cp.zeros_like(pixels, dtype=cp.float32)
    for i in range(3):
        idct_pixels[:, :, i] = apply_idct(pixels[:, :, i])

    return idct_pixels
